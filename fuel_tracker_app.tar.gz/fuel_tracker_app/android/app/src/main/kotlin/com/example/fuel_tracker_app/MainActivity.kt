package com.example.fuel_tracker_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
